oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

data = [
    85.1	64.9	64.9	85.1	85.1
    87      61.2	61.2	87      87
    85.4	51.2	51.2	85.5	85.4
    83      71.8	71.8	83      83
    86.4	49.4	49.4	85.5	86.4
    87.3	81.9	82      87.3	87.3
    72.3	52.2	52.1	72.1	72.3
    69.6	66.7	66.7	69.6	69.6
    68.2	47.8	47.7	66.2	68.2
    76.7	60.8	60.8	76.6	76.7
    86.8	73.2	73.2	86.8	86.8
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set accuracy from 0 to 100
ylim(gca, [0 100]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Post-filtering block accuracy - inhomo kernel');

%plot legend
legend('no privacy', '\varsigma_i=10^3, \varsigma_a=10^3', '\varsigma_i=10^3, \varsigma_a=10^7', '\varsigma_i=10^7, \varsigma_a=10^3', '\varsigma_i=10^7, \varsigma_a=10^7', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Accuracy (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

