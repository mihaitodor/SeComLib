oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

data = [
    76.8	80.6	85.1	83.9
    84.8	85.6	87      84.3
    82.3	85.9	85.4	86.8
    82.1	82.8	83      82.6
    83      85.4	86.4	84.4
    81.8	83.5	87.3	83.6
    63.9	67.3	72.3	69.4
    67.9	66.7	69.6	69.9
    60.7	64.7	68.2	68.4
    73      76.2	76.7	75.6
    82.9	85.8	86.8	85.7
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set accuracy from 0 to 100
ylim(gca, [0 100]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Post-filtering block accuracy');

%plot legend
legend('linear', 'poly', 'inhomo', 'radial', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Accuracy (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

