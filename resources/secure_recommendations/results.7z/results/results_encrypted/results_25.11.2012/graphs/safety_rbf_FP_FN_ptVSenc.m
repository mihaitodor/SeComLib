oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

FP = [
    87	75	75	58	87
    87	148	150	13	86
    79	473	473	80	83
    92	372	372	127	92
    95	123	124	24	99
    87	318	318	157	88
    124	127	126	126	129
    94	408	408	193	96
    110	457	459	11	112
    55	139	146	11	55
    60	76	76	10	62
];

FN = [
    74	440	440	131	71
    70	445	439	304	67
    53	62	62	56	51
    82	217	220	49	81
    61	431	429	274	61
    77	359	362	20	76
    182	403	403	183	181
    207	41	41	135	208
    206	40	37	329	207
    189	281	274	274	188
    83	240	235	180	84
];

%plot False Positives + False Negatives
totals = bar((FP + FN) / 10, 'grouped');

%set the texture of the totals plot
texture = gray;
colormap(texture(round(end / 3) : end, :));

hold on;

%plot False Positives
falsePositives = bar(FP / 10, 'grouped', 'k');

%set the OX ticks
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
%title('Post-filtering block - radial kernel: False positives (black) and false negatives per simulation');

%plot legend
legend('no privacy', '\varsigma_i=10^3, \varsigma_a=10^3', '\varsigma_i=10^3, \varsigma_a=10^7', '\varsigma_i=10^7, \varsigma_a=10^3', '\varsigma_i=10^7, \varsigma_a=10^7', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Incorrect predictions (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);
