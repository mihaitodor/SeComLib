oxLabels = {'\varsigma_i=10^3, \varsigma_a=10^3' '\varsigma_i=10^3, \varsigma_a=10^7' '\varsigma_i=10^7, \varsigma_a=10^3' '\varsigma_i=10^7, \varsigma_a=10^7'};

data = [
    4.535	20.639	26.287	24.286
    4.767	20.451	35.877	24.5
    7.145	41.997	53.875	26.245
    7.467	42.886	51.175	25.7
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Average runtime');

%plot legend
legend('linear', 'poly', 'inhomo', 'radial', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('System');
ylabel('Average runtime (s)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

