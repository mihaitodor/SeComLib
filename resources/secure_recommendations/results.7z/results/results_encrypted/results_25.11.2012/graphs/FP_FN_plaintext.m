oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

FP = [
    130	109	78	87
    99	72	79	87
    137	86	87	79
    113	108	110	92
    135	98	89	95
    82	89	73	87
    94	150	131	124
    34	137	97	94
    121	146	125	110
    43	64	66	55
    55	59	57	60
];

FN = [
    102	85	71	74
    53	72	51	70
    40	55	59	53
    66	64	60	82
    35	48	47	61
    100	76	54	77
    267	177	146	182
    287	196	207	207
    272	207	193	206
    227	174	167	189
    116	83	75	83
];

%plot False Positives + False Negatives
totals = bar(FP + FN, 'grouped');

%set the texture of the totals plot
texture = gray;
colormap(texture(round(end / 3) : end, :));

hold on;

%plot False Positives
falsePositives = bar(FP, 'grouped', 'k');

%set the OX ticks
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Post-filtering block without privacy: False positives (black) and false negatives per item');

%plot legend
legend('linear', 'poly', 'inhomo', 'radial', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Incorrect predictions');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

