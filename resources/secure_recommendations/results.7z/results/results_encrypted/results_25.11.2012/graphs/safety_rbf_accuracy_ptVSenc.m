oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

data = [
    83.9	48.5	48.5	81.1	84.2
    84.3	40.7	41.1	68.3	84.7
    86.8	46.5	46.5	86.4	86.6
    82.6	41.1	40.8	82.4	82.7
    84.4	44.6	44.7	70.2	84
    83.6	32.3	32      82.3	83.6
    69.4	47      47.1	69.1	69
    69.9	55.1	55.1	67.2	69.6
    68.4	50.3	50.4	66      68.1
    75.6	58      58      71.5	75.7
    85.7	68.4	68.9	81      85.4
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set accuracy from 0 to 100
ylim(gca, [0 100]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Ox
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Post-filtering block accuracy - radial kernel');

%plot legend
legend('no privacy', '\varsigma_i=10^3, \varsigma_a=10^3', '\varsigma_i=10^3, \varsigma_a=10^7', '\varsigma_i=10^7, \varsigma_a=10^3', '\varsigma_i=10^7, \varsigma_a=10^7', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Accuracy (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

