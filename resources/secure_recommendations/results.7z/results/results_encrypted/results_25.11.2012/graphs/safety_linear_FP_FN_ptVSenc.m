oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

FP = [
    130	124	124	130	130
    99	88	88	99	99
    137	79	79	136	136
    113	178	178	114	113
    135	321	321	134	134
    82	70	70	82	82
    94	400	400	97	97
    34	26	26	35	35
    121	167	167	121	121
    43	19	19	43	43
    55	33	33	55	55
];

FN = [
    102	121	120	102	102
    53	64	64	53	53
    40	499	499	39	39
    66	238	238	65	67
    35	143	143	35	35
    100	117	117	100	100
    267	129	129	267	267
    287	441	441	288	288
    272	237	237	272	272
    227	272	272	227	227
    116	150	150	116	116
];

%plot False Positives + False Negatives
totals = bar((FP + FN) / 10, 'grouped');

%set the texture of the totals plot
texture = gray;
colormap(texture(round(end / 3) : end, :));

hold on;

%plot False Positives
falsePositives = bar(FP / 10, 'grouped', 'k');

%set the OX ticks
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
%title('Post-filtering block - linear kernel: False positives (black) and false negatives per simulation');

%plot legend
legend('no privacy', '\varsigma_i=10^3, \varsigma_a=10^3', '\varsigma_i=10^3, \varsigma_a=10^7', '\varsigma_i=10^7, \varsigma_a=10^3', '\varsigma_i=10^7, \varsigma_a=10^7', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Incorrect predictions (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);
