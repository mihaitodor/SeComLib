oxLabels = {'\varsigma_i=10^3, \varsigma_a=10^3' '\varsigma_i=10^3, \varsigma_a=10^7' '\varsigma_i=10^7, \varsigma_a=10^3' '\varsigma_i=10^7, \varsigma_a=10^7'};

data = [
    478.92	1230.58	843.87	1013.2
    304.216	829.094	1324.23	777.933
    384.519	1111.53	3169.72	1102.18
    560.652	2172.04	2444.31	828.914
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Standard deviation');

%plot legend
legend('linear', 'poly', 'inhomo', 'radial', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('System');
ylabel('Standard deviation (ms)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

