oxLabels = {'no privacy' '\varsigma_i=10^3, \varsigma_a=10^3' '\varsigma_i=10^3, \varsigma_a=10^7' '\varsigma_i=10^7, \varsigma_a=10^3' '\varsigma_i=10^7, \varsigma_a=10^7'};

data = [
    89.1	92.1	92.8	92.7
    38.9	37.5	42.9	50.1
    38.9	37.5	43.2	50.2
    88.8	92.1	90.9	91.4
    89      92.1	92.8	92.5
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set accuracy from 0 to 100
ylim(gca, [0 100]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
%title('Medical relevance block accuracy');

%plot legend
legend('linear', 'poly', 'inhomo', 'radial', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('System');
ylabel('Accuracy (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

