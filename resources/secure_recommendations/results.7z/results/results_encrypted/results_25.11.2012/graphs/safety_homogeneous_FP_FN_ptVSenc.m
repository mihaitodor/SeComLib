oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

FP = [
    109	89	89	109	109
    72	127	127	72	72
    86	93	93	86	86
    108	102	102	104	108
    98	215	215	99	98
    89	135	135	90	89
    150	422	422	150	150
    137	10	10	137	137
    146	285	285	146	146
    64	272	272	64	64
    59	183	183	59	59
];

FN = [
    85	268	268	85	85
    72	444	444	72	72
    55	446	446	55	55
    64	343	343	65	64
    48	24	24	46	48
    76	251	251	76	76
    177	88	88	177	177
    196	379	379	196	196
    207	247	247	207	207
    174	205	205	174	174
    83	139	139	83	83
];

%plot False Positives + False Negatives
totals = bar((FP + FN) / 10, 'grouped');

%set the texture of the totals plot
texture = gray;
colormap(texture(round(end / 3) : end, :));

hold on;

%plot False Positives
falsePositives = bar(FP / 10, 'grouped', 'k');

%set the OX ticks
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
%title('Post-filtering block - poly kernel: False positives (black) and false negatives per simulation');

%plot legend
legend('no privacy', '\varsigma_i=10^3, \varsigma_a=10^3', '\varsigma_i=10^3, \varsigma_a=10^7', '\varsigma_i=10^7, \varsigma_a=10^3', '\varsigma_i=10^7, \varsigma_a=10^7', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Incorrect predictions (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);
