oxLabels = {'linear', 'poly', 'inhomo', 'radial'};

data = [
    89.1;	92.1;	92.8;	92.7;
];

%plot data
bar(data);

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set accuracy from 0 to 100
ylim(gca, [0 100]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Medical relevance block accuracy');

%set axes labels
xlabel('Kernels');
ylabel('Accuracy (%)');

