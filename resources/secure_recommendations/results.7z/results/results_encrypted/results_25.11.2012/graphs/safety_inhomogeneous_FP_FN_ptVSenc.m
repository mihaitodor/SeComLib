oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

FP = [
    78	147	147	78	78
    79	52	52	79	79
    87	8	8	89	87
    110	190	190	109	110
    89	237	236	111	89
    73	125	125	73	73
    131	424	424	138	131
    97	15	15	97	97
    125	410	409	208	125
    66	71	71	64	66
    57	215	215	58	57
];

FN = [
    71	204	204	71	71
    51	336	336	51	51
    59	480	480	56	59
    60	92	92	61	60
    47	269	270	34	47
    54	56	55	54	54
    146	54	55	141	146
    207	318	318	207	207
    193	112	114	130	193
    167	321	321	170	167
    75	53	53	74	75
];

%plot False Positives + False Negatives
totals = bar((FP + FN) / 10, 'grouped');

%set the texture of the totals plot
texture = gray;
colormap(texture(round(end / 3) : end, :));

hold on;

%plot False Positives
falsePositives = bar(FP / 10, 'grouped', 'k');

%set the OX ticks
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
%title('Post-filtering block - inhomo kernel: False positives (black) and false negatives per simulation');

%plot legend
legend('no privacy', '\varsigma_i=10^3, \varsigma_a=10^3', '\varsigma_i=10^3, \varsigma_a=10^7', '\varsigma_i=10^7, \varsigma_a=10^3', '\varsigma_i=10^7, \varsigma_a=10^7', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Incorrect predictions (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);
