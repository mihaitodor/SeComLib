oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

data = [
    80.6	64.3	64.3	80.6	80.6
    85.6	42.9	42.9	85.6	85.6
    85.9	46.1	46.1	85.9	85.9
    82.8	55.5	55.5	83.1	82.8
    85.4	76.1	76.1	85.5	85.4
    83.5	61.4	61.4	83.4	83.5
    67.3	49      49      67.3	67.3
    66.7	61.1	61.1	66.7	66.7
    64.7	46.8	46.8	64.7	64.7
    76.2	52.3	52.3	76.2	76.2
    85.8	67.8	67.8	85.8	85.8
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set accuracy from 0 to 100
ylim(gca, [0 100]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Post-filtering block accuracy - poly kernel');

%plot legend
legend('no privacy', '\varsigma_i=10^3, \varsigma_a=10^3', '\varsigma_i=10^3, \varsigma_a=10^7', '\varsigma_i=10^7, \varsigma_a=10^3', '\varsigma_i=10^7, \varsigma_a=10^7', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Accuracy (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

