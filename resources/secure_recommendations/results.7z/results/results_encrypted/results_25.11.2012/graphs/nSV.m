oxLabels = {'medical 1' 'medical 2' 'medical 3' 'medical 4' 'medical 5' 'medical 6' 'medical 7' 'medical 8' 'medical 9' 'medical 10' 'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

data = [
    566	289	258	230
    192	116	96	123
    532	278	224	204
    8	16	12	18
    34	29	28	28
    310	196	171	166
    8	11	8	8
    106	57	60	63
    27	50	38	25
    10	33	21	15
    602	494	377	279
    325	270	258	199
    385	328	323	249
    363	315	303	216
    347	291	287	215
    503	381	313	253
    577	517	434	325
    438	438	388	302
    456	418	329	254
    559	449	412	334
    403	275	276	202
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Support vector count');

%plot legend
legend('linear', 'poly', 'inhomo', 'radial', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Classifier');
ylabel('Support vectors');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

