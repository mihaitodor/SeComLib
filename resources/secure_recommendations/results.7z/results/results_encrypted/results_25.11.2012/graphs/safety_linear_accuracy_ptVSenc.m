oxLabels = {'item 1' 'item 2' 'item 3' 'item 4' 'item 5' 'item 6' 'item 7' 'item 8' 'item 9' 'item 10' 'item 11'};

data = [
    76.8	75.5	75.6	76.8	76.8
    84.8	84.8	84.8	84.8	84.8
    82.3	42.2	42.2	82.5	82.5
    82.1	58.4	58.4	82.1	82
    83      53.6	53.6	83.1	83.1
    81.8	81.3	81.3	81.8	81.8
    63.9	47.1	47.1	63.6	63.6
    67.9	53.3	53.3	67.7	67.7
    60.7	59.6	59.6	60.7	60.7
    73      70.9	70.9	73      73
    82.9	81.7	81.7	82.9	82.9
];

%plot data
bar(data, 'grouped');

%set the colormap
colormap(gray);

%set the OX scale
set(gca, 'XTick', 1 : length(oxLabels));

%limit the maximum value on Ox
xlim(gca,[0 (length(oxLabels) + 1)]);

%set accuracy from 0 to 100
ylim(gca, [0 100]);

%set custom labels on Ox
set(gca, 'XTickLabel', oxLabels);

%remove the top and right sides
set(gca, 'Box', 'off');

%remove tick marks
set(gca,'TickLength',[0 0]);

%plot dotted grid lines on Oy
set(gca, 'YGrid', 'on', 'GridLineStyle', ':');

%set title
title('Post-filtering block accuracy - linear kernel');

%plot legend
legend('no privacy', '\varsigma_i=10^3, \varsigma_a=10^3', '\varsigma_i=10^3, \varsigma_a=10^7', '\varsigma_i=10^7, \varsigma_a=10^3', '\varsigma_i=10^7, \varsigma_a=10^7', 'Location', 'NorthEastOutside');

%set axes labels
xlabel('Content items');
ylabel('Accuracy (%)');

%adjust the Ox Label positions
rotateticklabel(gca, 45);

